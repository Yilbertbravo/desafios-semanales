const Router = require("express");
const { getTareas, getTarea, createTarea, deleteTarea } = require("../controllers/tareas.controller.js");

const routes = Router();

routes
    .get("/", (req, res) => {
        getTareas(req, res);
    })
    .get("/:id", (req, res) => {
        getTarea(req, res);
    })
    .post("/", (req, res) => {
        createTarea(req, res);
    })
    .delete("/:id", (req, res) => {
        deleteTarea(req, res);
    });

module.exports = routes;