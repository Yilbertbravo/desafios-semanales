const { desconnect, getCollection, generateId } = require("../connection_db.js");
const { HEADER_CONTENT_TYPE } = require("../constants/headers.js");

const {
    ERROR_ID_NOT_FOUND,
    ERROR_DATA_MISSING,
    ERROR_SERVER,
} = require("../constants/messages.js");

const createSchema = (body) => {
    const { name, description } = body;

    return {
        name,
        description,
    };
};

// Controller para obtener tareas
const getTareas = async (req, res) => {
    res.set(HEADER_CONTENT_TYPE);

    try {
        const { name, description } = req.query;
        const filters = {};

        if (name) filters.name = { $regex: name, $options: "i" };
        if (description) filters.description = { $regex: description, $options: "i" };

        const collection = await getCollection("tareas");
        const tareas = await collection.find(filters).sort({ name: 1 }).toArray();

        res.status(200).send(tareas);
    } catch (error) {
        console.log(error.message);
        res.status(500).send({ message: ERROR_SERVER });
    } finally {
        await desconnect();
    }
};

// Controller para obtener una tarea por ID
const getTarea = async (req, res) => {
    res.set(HEADER_CONTENT_TYPE);

    try {
        const { id } = req.params;

        const collection = await getCollection("tareas");
        const { name, description } = req.body;

        const tarea = await collection.findOne({ id: Number(id) });

        if (!tarea) return res.status(400).send({ message: ERROR_ID_NOT_FOUND });

        console.log(`\nDescripcion de tarea encontrada:
        ID:${id}
        Nombre:${name}
        Descripcion:${description}
        \n`);

        res.status(200).send(tarea);
    } catch (error) {
        console.log(error.message);
        res.status(500).send({ message: ERROR_SERVER });
    } finally {
        await desconnect();
    }
};

// Controller para crear una tarea
const createTarea = async (req, res) => {
    res.set(HEADER_CONTENT_TYPE);

    try {
        const { name, description } = await req.body;

        if (!name || !description ) return res.status(400).send({ message: ERROR_DATA_MISSING });

        const collection = await getCollection("tareas");
        const id = await generateId(collection);
        const tarea = { id, ...createSchema(req.body) };
        await collection.insertOne(tarea);

        console.log(`\nCreada exitosamente la tarea: ${name}\n`);
        res.status(201).send(tarea);
    } catch (error) {
        console.log(error.message);
        res.status(500).send({ message: ERROR_SERVER });
    } finally {
        await desconnect();
    }
};

// Controller para eliminar una tarea en específico por ID
const deleteTarea = async (req, res) => {
    res.set(HEADER_CONTENT_TYPE);

    try {
        const { id } = req.params;
        const { name } = req.body;

        const collection = await getCollection("tareas");
        const tarea = await collection.find({ id: Number(id) }).toArray();

        if (tarea.length === 0) return res.status(400).send({ message: ERROR_ID_NOT_FOUND });
        console.log(`\nEliminada exitosamente la tarea: ${name}\n`);

        await collection.deleteOne({ id: Number(id) });

        res.status(200).send(tarea);
    } catch (error) {
        console.log(error.message);
        res.status(500).send({ message: ERROR_SERVER });
    } finally {
        await desconnect();
    }
};

module.exports = { getTareas, getTarea, createTarea, deleteTarea };