import { useEffect, useState } from "react";
import AddTodo from "./AddTodo.jsx";
import TaskList from "./TaskList.jsx";
import useLocalStorage from "./hooks/useLocalStorage.js";

import "./app.scss";
import "../components/layout/header.scss";
import "../components/layout/main.scss";
import "../components/layout/footer.scss";


const initialTodos = [];

export default function App() {
    const [todos, setTodos] = useState(initialTodos);

    const localStorage = useLocalStorage({todosProductos: []});

    useEffect(() => {
        const newTodos = localStorage.getItemValue("todosProductos");
        setTodos(newTodos);
    }, []);


    const generateId = () => {
        let numberId = 0;
        todos.forEach((lista) => {
            if (lista.id > numberId) {
                numberId = lista.id;
            }
        });

        return numberId + 1;
    };

    function handleAddTodo(title, price, description) {
        let newTodos = [
            ...todos,
            {
                id: generateId(),
                title: title,
                price: price,
                description: description,
                favorito: false
            }
        ];
        filterOrder(newTodos);

        setTodos(newTodos);
        console.log("todos", todos);
        console.log("new todos", newTodos);
    }

    function  filterOrder(f) {
        f.sort(function (a, b){
            return ( a.title.toLowerCase().localeCompare(b.title.toLowerCase()));
        });
    }

    const addLocalFun = () => {
        localStorage.setItem("todosProductos", todos );
    };

    function handleChangeTodo(nextTodo) {
        setTodos(todos.map(t => {
            if (t.id === nextTodo.id) {
                return nextTodo;
            } else {
                return t;
            }
        }));

    }

    function handleDeleteTodo(todoId) {
        let deleteTodos =  todos.filter(t => t.id !== todoId);

        setTodos(deleteTodos);
    }


 
    return (
        <>
            <div className="header">
                <h1 className="title">Inventario de productos</h1>
            </div>

            <main  className="main">
                <AddTodo
                    onAddTodo={handleAddTodo}
                    localStorageFunc= {addLocalFun}

                />
                <TaskList
                    todos={todos}
                    onChangeTodo={handleChangeTodo}
                    onDeleteTodo={handleDeleteTodo}

                />
            </main>
           

            <footer  className="footer">
                <p>&copy Derechos Reservados - Desafio semanal 16</p>
            </footer>
        </>
    );
}

