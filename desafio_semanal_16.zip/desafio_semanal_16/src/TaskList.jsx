import { useState } from "react";
import PropTypes from "prop-types";

import "./app.scss";
import "../components/layout/header.scss";
import "../components/layout/main.scss";
import "../components/layout/footer.scss";


const TaskList = (props) => {

    const { todos,  onChangeTodo, onDeleteTodo } = props;

    TaskList.propTypes = {
        todos: PropTypes.array,
        onChangeTodo: PropTypes.func,
        onDeleteTodo: PropTypes.func,

    };


    return (

        <div className="list__task">
            <h2><span><img src="../public/images/list.png"/></span>Lista de productos</h2>

            <table className="list__task__table">
                <thead>
                    <tr>
                        <th>Favorito</th>
                        <th>Nombre Producto</th>
                        <th>Precio</th>
                        <th>Descripción</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>

                { todos.map(todo => (
                    <tr key={todo.id}>
                        <Task
                            todo={todo}
                            onChange={onChangeTodo}
                            onDelete={onDeleteTodo}
                        />
                    </tr>
                ))}
            </table>
        </div>

    );
};

const Task = (props) => {

    const { todo,  onChange, onDelete } = props;

    Task.propTypes = {
        todo: PropTypes.object,
        onChange: PropTypes.func,
        onDelete: PropTypes.func,
    };


    const [isEditing, setIsEditing] = useState(false);
    let todoContent;
    if (isEditing) {
        todoContent = (
            <>
                <td>
                    <input
                        type="checkbox"
                        checked={todo.favorito}
                        onChange={e => {
                            onChange({
                                ...todo,
                                favorito: e.target.checked
                            });
                        }}
                    /></td>
                <td>
                    <input
                        value={todo.title}
                        onChange={e => {
                            onChange({
                                ...todo,
                                title: e.target.value
                            });
                        }} />
                </td>

                <td>
                    <input
                        value={todo.price}
                        onChange={e => {
                            onChange({
                                ...todo,
                                price: e.target.value
                            });
                        }} />
                </td>

                <td>
                    <input
                        value={todo.description}
                        onChange={e => {
                            onChange({
                                ...todo,
                                description: e.target.value
                            });
                        }} />
                </td>
                <button className="buttonSave" onClick={() => setIsEditing(false)}>
          Guardar
                </button>
            </>
        );
    } else {
        todoContent = (
            <>
                <td>
                    <input
                        type="checkbox"
                        checked={todo.favorito}
                        onChange={e => {
                            onChange({
                                ...todo,
                                favorito: e.target.checked
                            });
                        }}
                    /></td>
                <td> {todo.title} </td>
                <td>  {todo.price} </td>
                <td>  {todo.description} </td>
                <td>   <button className="buttonEdit" onClick={() => setIsEditing(true)}> Editar </button> </td>
                <td>  <button className="buttonDelete" onClick={() => onDelete(todo.id)}> Eliminar </button> </td>

            </>
        );
    }
    return (
        <>
            {todoContent}
        </>

    
    );
};


export default TaskList;