import { useState } from "react";
import PropTypes from "prop-types";

import "./app.scss";
import "../components/layout/header.scss";
import "../components/layout/main.scss";
import "../components/layout/footer.scss";


const AddTodo = (props) => {
    const { onAddTodo, localStorageFunc } = props;

    AddTodo.propTypes = {
        onAddTodo: PropTypes.func,
        localStorageFunc: PropTypes.func,
    };

    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");

    const inputName = document.getElementById("name");
    const inputPrice = document.getElementById("price");
    const inputDescription = document.getElementById("description");

    const REGEX_PRICE = /^[(][0-9]{3,4}[)][0-9]{3}[-][0-9]{4,8}$/;
    const REGEX_NAME = /^[a-zA-Z\s]{4,}$/;
    const nom = "Nombre";
    const pre = "Precio";
    const desc = "Descripción";


    const validate = (regex, valor, inputValue) => {
        if (!regex.test(valor.value)) {
            return valor.nextElementSibling.innerHTML = `${inputValue} ingresado es invalido, favor editarlo en la tabla e ingrese otro producto`;
        } else {
            valor.nextElementSibling.innerHTML = "";
        }
    };


    return (
        <div className="enter__task">
            <label htmlFor="task">Ingresar un producto al inventario:</label>
            <input
                id="name"
                label="Nombre"
                name="name"
                placeholder="Nombre de producto"
                autoFocus
                value={title}
                onChange={e => setTitle(e.target.value)}
            />
            <label htmlFor="name" className="label-info"></label>

            <input
                id="price"
                label="Precio"
                name="price"
                placeholder="Precio de producto"
                value={price}
                onChange={e => setPrice(e.target.value)}
            />
            <label htmlFor="price" className="label-info"></label>

            <input
                id="description"
                label="Descripcion"
                name="description"
                placeholder="Descripcion corta de producto"
                value={description}
                onChange={e => setDescription(e.target.value)}
            />
            <label htmlFor="description" className="label-info"></label>

            <button onClick={() => {
                validate(REGEX_NAME, inputName, nom);
                validate(REGEX_PRICE, inputPrice, pre);
                validate(REGEX_NAME, inputDescription, desc);
                setTitle("");
                setPrice("");
                setDescription("");
                onAddTodo(title, price, description);
                localStorageFunc();
                // validator(title, price, description);
            }}
            >Guardar</button>
        </div>
    );
};

export default AddTodo;