import TaskForm from "./TaskForm";
import "./app.scss";


const App = () => {


    return (
        <>
            <div className="header">
                <h1 className="title"><span><img src="../public/images/list.png"/></span>Lista de tareas a realizar por el operario</h1>
            </div>

            <TaskForm className="main"/>

            <footer  className="footer">
                <p>&copy Derechos Reservados - Desafio semanal 13</p>
            </footer>
        </>
    );
};

export default App;
