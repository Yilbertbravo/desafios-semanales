import "./app.scss";
import ClimaCiudad from "./components/ClimaCiudad";

const App = () => {

    return (
        <>
            <div className="header">
                <h1>Aplicación Meteorológica</h1>
            </div>
            <div className="main">
                <ClimaCiudad/>
            </div>
            <div className="footer">
                <span>Todos los derechos reservados - Desafio Semanal 15</span>
            </div>
        </>
    );
};

export default App;