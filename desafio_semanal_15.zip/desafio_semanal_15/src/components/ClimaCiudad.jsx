import { useEffect, useState } from "react";

const ClimaCiudad = () => {
    const [ arrayClima, setArrayClima ] = useState();
    const [ city, setCity ] = useState("");

    const URL = "https://api.openweathermap.org/data/2.5/weather?&units=metric&appid=493ef5521eaccd20f7b2e16bc7b74a89&leng=es";
    const cityUrl = "&q=";
    const ciudad = city;
    const URLAPI = URL + cityUrl + ciudad;

    useEffect(() => {
        fetch(`${URLAPI}`)
            .then((response) => response.json())
            .then((data) => setArrayClima(data));
    }, [city]);

    const handleOnChangeCity = (e) => {
        setCity(e.target.value);

    };

    const handleOnClickSaveArray = () => {
        handleOnChangeCity;
        if (city === "") {
            const ciudad = document.getElementById("idNombre");
            ciudad.innerHTML = "Ingrese una ciudad conocida";
        }
        const datos = {
            nombre: arrayClima.name,
            id: arrayClima.id,
            temp: arrayClima.main.temp,
            icono: arrayClima.weather[0].icon,
        };
        const ciudad = document.getElementById("idNombre");
        const imgURL = document.getElementById("icon--img");
        const temperatura = document.getElementById("idTemperatura");
        const warning = document.getElementById("idWarning");

        ciudad.innerHTML = datos.nombre;
        temperatura.innerHTML = datos.temp + " °C";
        const comparation = datos.temp;
        imgURL.setAttribute("src", "../../public/images/" + datos.icono + ".png");

        if (comparation < 30 && comparation > 10) { warning.innerHTML = "";
        } if (comparation > 30) { warning.innerHTML = "Hace mucho Calor";
        } if (comparation < 10) { warning.innerHTML = "Hace mucho Frio";}
    };

    return (
        <div>
            <h2>Elige tu Ciudad preferida</h2>
            <div>
                <input
                    type="search"
                    placeholder="Ciudad..."
                    value={city}
                    onChange={handleOnChangeCity}
                />
                <button onClick={handleOnClickSaveArray}>Buscar</button>
            </div>

            <div id="container">
                <div className="titulo">
                    <h2 id="idNombre"></h2>
                </div>

                <div className="icono">
                    <img
                        id="icon--img"
                    />
                </div>

                <span id="idTemperatura"></span>

                <div className="warning">
                    <span id="idWarning"></span>
                </div>

            </div>

        </div>
    );
};

export default ClimaCiudad;