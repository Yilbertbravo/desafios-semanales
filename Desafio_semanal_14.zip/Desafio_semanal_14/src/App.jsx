import { useState } from "react";
import AddTodo from "./AddTodo.jsx";
import TaskList from "./TaskList.jsx";

import "./app.scss";
import "../components/layout/header.scss";
import "../components/layout/main.scss";
import "../components/layout/footer.scss";


const initialTodos = [];

export default function App() {
    const [todos, setTodos] = useState(initialTodos);

    const generateId = () => {
        let numberId = 0;

        todos.forEach((lista) => {
            if (lista.id > numberId) {
                numberId = lista.id;
            }
        });

        return numberId + 1;
    };

    function handleAddTodo(title) {
        setTodos([
            ...todos,
            {
                id: generateId(),
                title: title,
                favorito: false
            }
        ]);
    }

    function handleChangeTodo(nextTodo) {
        setTodos(todos.map(t => {
            if (t.id === nextTodo.id) {
                return nextTodo;
            } else {
                return t;
            }
        }));
    }

    function handleDeleteTodo(todoId) {
        setTodos(
            todos.filter(t => t.id !== todoId)
        );
    }

    return (
        <>
            <div className="header">
                <h1 className="title"><span><img src="../public/images/lista.png"/></span>Lista de tareas a realizar por el operario</h1>
            </div>

            <main  className="main">
                <AddTodo
                    onAddTodo={handleAddTodo}
                />
                <TaskList
                    todos={todos}
                    onChangeTodo={handleChangeTodo}
                    onDeleteTodo={handleDeleteTodo}
                />
            </main>
           

            <footer  className="footer">
                <p>&copy Derechos Reservados - Desafio semanal 14</p>
            </footer>
        </>
    );
}

