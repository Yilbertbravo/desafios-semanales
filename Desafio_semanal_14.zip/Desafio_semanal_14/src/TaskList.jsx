import { useState } from "react";
import PropTypes from "prop-types";

import "./app.scss";
import "../components/layout/header.scss";
import "../components/layout/main.scss";
import "../components/layout/footer.scss";


const TaskList = (props) => {

    const { todos,  onChangeTodo, onDeleteTodo } = props;

    TaskList.propTypes = {
        todos: PropTypes.array,
        onChangeTodo: PropTypes.func,
        onDeleteTodo: PropTypes.func,
    };

    return (

        <div className="list__task">
            <h2><span><img src="../public/images/list.png"/></span>Lista de tareas</h2>

            <ul>
                {todos.map(todo => (
                    <li key={todo.id}>
                        <Task
                            todo={todo}
                            onChange={onChangeTodo}
                            onDelete={onDeleteTodo}
                        />
                    </li>
                ))}
            </ul>
        </div>

    );
};

const Task = (props) => {

    const { todo,  onChange, onDelete } = props;

    Task.propTypes = {
        todo: PropTypes.object,
        onChange: PropTypes.func,
        onDelete: PropTypes.func,
    };


    const [isEditing, setIsEditing] = useState(false);
    let todoContent;
    let listaFavoritos;
    if (isEditing) {
        todoContent = (
            <>
                <input
                    value={todo.title}
                    onChange={e => {
                        onChange({
                            ...todo,
                            title: e.target.value
                        });
                    }} />
                <button className="buttonSave" onClick={() => setIsEditing(false)}>
          Guardar
                </button>
            </>
        );
    } else {
        todoContent = (
            <>
                {todo.title}
                <button className="buttonEdit" onClick={() => setIsEditing(true)}>
          Editar
                </button>
            </>
        );
    }
    return (
        <label>
            <input
                type="checkbox"
                checked={todo.favorito}
                onChange={e => {
                    onChange({
                        ...todo,
                        favorito: e.target.checked
                    });
                }}
            />
            {todoContent}
            <button className="buttonDelete" onClick={() => onDelete(todo.id)}>
        Eliminar
            </button>
            {listaFavoritos}
        </label>

    
    );
};


export default TaskList;