import { useState } from "react";
import PropTypes from "prop-types";

import "./app.scss";
import "../components/layout/header.scss";
import "../components/layout/main.scss";
import "../components/layout/footer.scss";


const AddTodo = (props) => {
    const { onAddTodo } = props;

    AddTodo.propTypes = {
        onAddTodo: PropTypes.func,
    };

    const [title, setTitle] = useState("");
    return (
        <div className="enter__task">
            <label htmlFor="task">Ingresar tarea para agregarle al operario:</label>
            <input
                autoFocus
                value={title}
                onChange={e => setTitle(e.target.value)}
            />
            <button onClick={() => {
                setTitle("");
                onAddTodo(title);
            }}>Guardar Tarea</button>
        </div>
    );
};

export default AddTodo;